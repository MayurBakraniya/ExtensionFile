//
//  ViewController.swift
//  insta
//
//  Created by Mayur.bakraniya on 07/02/23.
//

import UIKit
import AVFoundation
import InstaProgressView

class ViewController: UIViewController {
    
    var progressView = InstaProgressView(progressTintColor: .white, trackTintColor: UIColor.white.withAlphaComponent(0.5), segmentsCount: 5, spaceBetweenSegments: 8, duration: 10)
    
    var player: AVPlayer!
    var avPlayerLayer:AVPlayerLayer!
    //    var urlArray:[String] =["your file link","your file link"]
    
    var btn_index = 1
    
    let urls = [
        "http://techslides.com/demos/sample-videos/small.mp4",
        "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        "http://techslides.com/demos/sample-videos/small.mp4",
        "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        "http://techslides.com/demos/sample-videos/small.mp4"
    ]
        
    var urlLoad = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupGesturesRecognizers()
        print(self.urlLoad)
        
        progressView = InstaProgressView(progressTintColor: .black, trackTintColor: UIColor.white, segmentsCount: urls.count, spaceBetweenSegments: 8, duration: 10)
    }
    
    func downloadVideo(videoUrl:String,index:Int){
        
        let docsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        _ = NSUUID().uuidString
        let randomString = URL(string: videoUrl)?.lastPathComponent
        let path = randomString?.components(separatedBy: ".")
        print(path?[0] as Any)
        let destinationUrl = docsUrl.appendingPathComponent("\(path?[0] ?? "").mp4")
        if(FileManager().fileExists(atPath: destinationUrl.path)){
            let path = destinationUrl.path
            print("\n\nfile already exists \(path)\n\n")
            
            urlLoad.append(path)
            
            print(urlLoad)
        }
        else{
            DispatchQueue.global(qos: .background).async {
                var request = URLRequest(url: URL(string: videoUrl)!)
                request.httpMethod = "GET"
                URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
                    if(error != nil){
                        print("\n\nsome error occured\n\n")
                        return
                    }
                    if let response = response as? HTTPURLResponse{
                        if response.statusCode == 200{
                            DispatchQueue.main.async {
                                if let data = data{
                                    if let data_json = try? data.write(to: destinationUrl, options: Data.WritingOptions.atomic){
                                        print("\n\nurl data written \(data_json)\n\n")
                                    }
                                    else{
                                        print("\n\nerror again\n\n")
                                    }
                                }//end if let data
                            }//end dispatch main
                        }//end if let response.status
                    }
                }).resume()
            }//end dispatch global
        }//end outer else
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        progressViewSetup()
    }
    
    private func progressViewSetup() {
        view.superview?.addSubview(progressView)
        progressView.delegate = self
        progressView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20).isActive = true
        progressView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10).isActive = true
        progressView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10).isActive = true
        progressView.heightAnchor.constraint(equalToConstant: 6).isActive = true
        progressView.translatesAutoresizingMaskIntoConstraints = false
        
        progressView.startAnimation()
        
    }
    
    private func setupGesturesRecognizers() {
        let longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(longPressed))
        view.addGestureRecognizer(longPressRecognizer)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
        swipeLeft.direction = .left
        view.addGestureRecognizer(swipeLeft)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
        swipeRight.direction = .right
        view.addGestureRecognizer(swipeRight)
    }
    
    @objc private func handleGesture(gesture: UISwipeGestureRecognizer) {
        if gesture.direction == .right {
            progressView.back()
            print("back")
        }else if gesture.direction == .left {
            progressView.skip()
            print("skip")
        }
    }
    
    @objc private func longPressed(sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            print("pause")
            progressView.pauseAnimation()
            self.player.pause()
        }
        if sender.state == .ended {
            print("continueLoading")
            progressView.continueAnimation()
            self.player.play()
        }
    }
}


extension ViewController: InstaProgressViewDelegate {
    
    func instaProgressViewChangedIndex(index: Int) {
        
        print("all downloads \(index)")
        let st = urls[index]
        downloadVideo(videoUrl: st, index: index)
        
        if urlLoad.count != 0 && urlLoad.count > 5{
            let d = urlLoad[index]
            print("play local")
            
            self.player = AVPlayer(url: URL(fileURLWithPath: d))
            self.avPlayerLayer = AVPlayerLayer(player: self.player)
            self.avPlayerLayer.frame = self.view.bounds
            self.avPlayerLayer.videoGravity = .resizeAspectFill
            self.view.layer.addSublayer(self.avPlayerLayer)
            self.player.play()
        }else{
            print("play live")
            self.player = AVPlayer(url: URL(string: st)!)
            self.avPlayerLayer = AVPlayerLayer(player: self.player)
            self.avPlayerLayer.frame = self.view.bounds
            self.avPlayerLayer.videoGravity = .resizeAspectFill
            self.view.layer.addSublayer(self.avPlayerLayer)
            self.player.play()
            let st = urls[index + 1]
            downloadVideo(videoUrl: st, index: index)
        }
    }
    
    func instaProgressViewFinished() {
        print("Finished")
        progressView.pauseAnimation()
        player.pause()
    }
}

extension String {
    
    static func random(length: Int = 5) -> String {
        let base = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        var randomString: String = ""
        
        for _ in 0..<length {
            let randomValue = arc4random_uniform(UInt32(base.count))
            randomString += "\(base[base.index(base.startIndex, offsetBy: Int(randomValue))])"
        }
        return randomString
    }
}
