//
//  ViewController.swift
//  ContainerView
//
//  Created by Mayur.bakraniya on 10/02/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var segmentview: UIView!
    
    private var spb: SegmentedProgressBar!
    var container: ContainerViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        spb = SegmentedProgressBar(numberOfSegments: 5, duration: 5)
        spb.frame = CGRect(x: 15, y: 15, width: view.frame.width - 30, height: 4)
        spb.topColor = UIColor.white
        spb.delegate = self
        spb.padding = 2
        segmentview.addSubview(spb)
        
        spb.startAnimation()
        
        setupGesturesRecognizers()
    }
    
    private func setupGesturesRecognizers() {
        let longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(longPressed))
        view.addGestureRecognizer(longPressRecognizer)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
        swipeLeft.direction = .left
        view.addGestureRecognizer(swipeLeft)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
        swipeRight.direction = .right
        view.addGestureRecognizer(swipeRight)
    }
    
    @objc private func handleGesture(gesture: UISwipeGestureRecognizer) {
        if gesture.direction == .right {
            spb.rewind()
            print("back")
        }else if gesture.direction == .left {
            spb.skip()
            print("skip")
        }
    }
    
    @objc private func longPressed(sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            print("pause")
            spb.isPaused = true
//            VideoPlayer().pause()
        }
        if sender.state == .ended {
            print("continueLoading")
            spb.isPaused = false
//            VideoPlayer().play()
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "container"{
            container = segue.destination as? ContainerViewController
            
            container.animationDurationWithOptions = (0.1, .transitionCrossDissolve)
        }else {
                print("Handle conatiner")
//            guard let sideMenuNavigationController = segue.destination as? SideMenuNavigationController else { return }
//            sideMenuNavigationController.settings = makeSettings()
        }
    }
}

extension ViewController:SegmentedProgressBarDelegate{
    
    func segmentedProgressBarChangedIndex(index: Int) {
        if index == 0{
            container!.segueIdentifierReceivedFromParent("story0")
        }else if index == 1{
            container!.segueIdentifierReceivedFromParent("story1")
        }else if index == 2{
            container!.segueIdentifierReceivedFromParent("story2")
        }else if index == 3{
            container!.segueIdentifierReceivedFromParent("story3")
        }else if index == 4{
            container!.segueIdentifierReceivedFromParent("story4")
        }
    }
    
    func segmentedProgressBarFinished() {
        print("finish")
    }
}
