//
//  ViewController1.swift
//  ContainerView
//
//  Created by Mayur.bakraniya on 10/02/23.
//

import UIKit
import AVKit
import AVFoundation

class ViewController1: UIViewController {
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        guard let path = Bundle.main.path(forResource: "video", ofType:"mp4") else {
            debugPrint("video.m4v not found")
            return
        }

        VideoPlayer().addVideo(url: URL(fileURLWithPath: path))
        
    }
}
