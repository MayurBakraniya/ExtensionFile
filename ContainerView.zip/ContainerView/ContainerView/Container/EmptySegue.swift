//
//  EmptySegue.swift
//  SegmentedProgressBar
//
//  Created by Mayur.bakraniya on 10/02/23.
//  Copyright © 2023 Dylan Marriott. All rights reserved.
//

import UIKit

class EmptySegue: UIStoryboardSegue{
    
    override func perform() {
    
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
